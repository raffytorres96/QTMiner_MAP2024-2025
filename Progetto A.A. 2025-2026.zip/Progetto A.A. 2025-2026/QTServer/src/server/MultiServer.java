package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import javax.sound.sampled.Port;

public class MultiServer {

    private int PORT = 8080;

    public MultiServer(int port){
        this.PORT = port;
        run();
    }

    public void run(){
        try {
            ServerSocket serverSocket = new ServerSocket();
            
            while(true){
                Socket clientSocket = serverSocket.accept();
                System.out.println("Nuova connessione da " + clientSocket.getInetAddress());

                new ServerOneClient(clientSocket).start();
            }
        } catch (IOException e) {
            System.out.println("Errore nel server: " + e.getMessage());;
        }
    }

    public static void main(String[] args){
        int PORT = 8080;
        MultiServer multiserver = new MultiServer(PORT);
    }

}
